import React from 'react';

const CampagneList = ({ campagnes }) => {
  const lancerAnalyse = async (campagne) => {
    try {
      const response = await fetch('http://localhost:8081/api/v1/dags/detect_campagne_dag/dagRuns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conf: {
            nom: campagne.nom,
            anneeReference: 2023, // à rendre dynamique plus tard si tu veux
            seuil: campagne.seuilConsommation
          }
        })
      });

      if (response.ok) {
        alert('✅ DAG lancé avec succès !');
      } else {
        alert('❌ Échec du lancement du DAG');
      }
    } catch (error) {
      console.error('Erreur:', error);
      alert('⚠️ Erreur lors de l’appel à Airflow');
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Liste des campagnes</h2>
      <table className="table-auto w-full border">
        <thead>
          <tr>
            <th>Nom</th>
            <th>Seuil</th>
            <th>Fluide</th>
            <th>Nature</th>
            <th>Demandeur</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {campagnes.map((campagne, index) => (
            <tr key={index}>
              <td>{campagne.nom}</td>
              <td>{campagne.seuilConsommation}</td>
              <td>{campagne.fluideConcerne}</td>
              <td>{campagne.nature}</td>
              <td>{campagne.demandeur}</td>
              <td>
                <button
                  onClick={() => lancerAnalyse(campagne)}
                  className="bg-blue-500 text-white px-2 py-1 rounded"
                >
                  Lancer l’analyse
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CampagneList;

import React, { useEffect, useState } from 'react';

const ResultatsCampagne = () => {
  const [resultats, setResultats] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8080/api/resultats') // adapte selon ton backend
      .then(res => res.json())
      .then(data => setResultats(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Résultats des campagnes</h2>
      <table className="table-auto w-full border">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Compteur</th>
            <th>Consommation</th>
            <th>Localisation</th>
            <th>Date de pose</th>
          </tr>
        </thead>
        <tbody>
          {resultats.map((dossier, i) => (
            <tr key={i}>
              <td>{dossier.id}</td>
              <td>{dossier.nomCampagne}</td>
              <td>{dossier.typeCompteur}</td>
              <td>{dossier.historiqueConsommation}</td>
              <td>{dossier.positionGeo}</td>
              <td>{dossier.datePose}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ResultatsCampagne;
